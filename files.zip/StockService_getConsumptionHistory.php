<?php
declare(strict_types=1);

namespace App\Services\Nexus;

// ─────────────────────────────────────────────────────────────────────────────
// StockService::getConsumptionHistory()
// Closes the gap identified in WMM Session 008.
// Called by: StockForecastService — 90-day window feeds AI forecast.
// Source table: medicines_outgoing_list (MedicineOutgoingList model)
// Fields confirmed from scan: medicine_id, ambulance_id, quantity, used_at
// ─────────────────────────────────────────────────────────────────────────────

// ADD THIS METHOD to app/Services/Nexus/StockService.php

    /**
     * Returns 90-day consumption history per medicine for a given ambulance.
     * AI-safe: no PHI — medicine names + quantities + dates only.
     * Called by StockForecastService before inference.
     *
     * @return array  [['medicine' => string, 'date' => string, 'qty_used' => float], ...]
     */
    public function getConsumptionHistory(int $ambulanceId, int $days = 90): array
    {
        return MedicineOutgoingList::where('ambulance_id', $ambulanceId)
            ->where('used_at', '>=', now()->subDays($days))
            ->join(
                'medicines_definition',
                'medicines_outgoing_list.medicine_id',
                '=',
                'medicines_definition.id'
            )
            ->select([
                'medicines_definition.name          as medicine',
                'medicines_outgoing_list.quantity   as qty_used',
                'medicines_outgoing_list.used_at    as date',
            ])
            ->orderBy('medicines_outgoing_list.used_at', 'asc')
            ->get()
            ->map(fn($row) => [
                'medicine' => $row->medicine,
                'qty_used' => (float) $row->qty_used,
                'date'     => $row->date,
            ])
            ->toArray(); // No PHI — safe to pass to NexusBrainClient
    }

    /**
     * Aggregated daily consumption — used by StockForecastPrompt for trend analysis.
     * Groups by medicine + day to reduce token payload to AI.
     *
     * @return array  [['medicine' => string, 'avg_daily_usage' => float, 'peak_daily' => float, 'days_with_usage' => int], ...]
     */
    public function getConsumptionSummary(int $ambulanceId, int $days = 90): array
    {
        return MedicineOutgoingList::where('ambulance_id', $ambulanceId)
            ->where('used_at', '>=', now()->subDays($days))
            ->join(
                'medicines_definition',
                'medicines_outgoing_list.medicine_id',
                '=',
                'medicines_definition.id'
            )
            ->selectRaw("
                medicines_definition.name          AS medicine,
                AVG(medicines_outgoing_list.quantity) AS avg_daily_usage,
                MAX(medicines_outgoing_list.quantity) AS peak_daily,
                COUNT(DISTINCT DATE(medicines_outgoing_list.used_at)) AS days_with_usage
            ")
            ->groupBy('medicines_definition.id', 'medicines_definition.name')
            ->orderByDesc('avg_daily_usage')
            ->get()
            ->map(fn($row) => [
                'medicine'       => $row->medicine,
                'avg_daily_usage'=> round((float) $row->avg_daily_usage, 3),
                'peak_daily'     => round((float) $row->peak_daily, 3),
                'days_with_usage'=> (int) $row->days_with_usage,
            ])
            ->toArray();
    }

// ─────────────────────────────────────────────────────────────────────────────
// UPDATE StockForecastService::forecast() to use getConsumptionSummary()
// Summary is more token-efficient than raw history for AI prompt
// ─────────────────────────────────────────────────────────────────────────────

// REPLACE this line in StockForecastService::forecast():
//   $consumptionHistory = $this->stock->getConsumptionHistory($ambulanceId, days: self::HISTORY_DAYS);
//
// WITH:
//   $consumptionHistory = $this->stock->getConsumptionSummary($ambulanceId, days: self::HISTORY_DAYS);
//
// Reason: getConsumptionSummary() returns ~N rows (one per medicine)
//         getConsumptionHistory() returns ~N*90 rows (one per dispensing event)
//         Summary is 90x smaller — far fewer tokens sent to Claude

// ─────────────────────────────────────────────────────────────────────────────
// UPDATE StockForecastPrompt::userContent() to use summary format
// ─────────────────────────────────────────────────────────────────────────────

    public function userContent(): string
    {
        return json_encode([
            'ambulance_id'        => $this->ambulanceId,
            'forecast_days'       => $this->days,
            'current_levels'      => $this->levels,      // from StockService::getLevels()
            'expiring_soon'       => $this->expiring,    // from StockService::getExpiringItems()
            'consumption_summary' => $this->history,     // from StockService::getConsumptionSummary()
            // Structure of consumption_summary:
            // [{ medicine, avg_daily_usage, peak_daily, days_with_usage }, ...]
        ], JSON_PRETTY_PRINT);
    }

// ─────────────────────────────────────────────────────────────────────────────
// ALSO ADD to MedicineOutgoingList model (use statement in StockService):
// ─────────────────────────────────────────────────────────────────────────────
// use App\Models\Version1\Medicine\MedicineOutgoingList;
// (already listed in StockService Session 004 scaffold — confirm import present)

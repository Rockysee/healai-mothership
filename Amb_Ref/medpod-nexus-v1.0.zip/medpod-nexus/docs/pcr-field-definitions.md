# PCR Field Definitions — NEMSIS Standard

MEDPOD NEXUS PCR (Patient Care Record) fields are aligned to the
**NEMSIS v3.5 Data Standard** (National EMS Information System).
NEMSIS is a public international standard — these definitions are not proprietary.

## PCR Structure — 15 Sections

### 1. ePatient — Patient Demographics
*PHI section — always de-identified before AI inference*

| Field | NEMSIS Element | Type | PHI? |
|---|---|---|---|
| patient_id | ePatient.01 | string | ✅ Strip |
| patient_name | ePatient.02 | string | ✅ Strip |
| dob | ePatient.17 | date | ✅ Strip |
| gender | ePatient.13 | enum | No |
| age | ePatient.15 | integer | No (approximate) |
| weight_kg | ePatient.19 | float | No |
| abha_id | ePatient.IndiaABHA | string | ✅ Strip |

### 2. eVitals — Vital Signs
*Clinical data — safe for de-identified AI inference*

| Field | NEMSIS Element | Normal Range | Unit |
|---|---|---|---|
| heart_rate | eVitals.10 | 60-100 | bpm |
| respiratory_rate | eVitals.14 | 12-20 | breaths/min |
| spo2 | eVitals.20 | 95-100 | % |
| gcs_total | eVitals.23 | 3-15 | score |
| gcs_eye | eVitals.24 | 1-4 | score |
| gcs_verbal | eVitals.25 | 1-5 | score |
| gcs_motor | eVitals.26 | 1-6 | score |
| systolic_bp | eVitals.06 | 90-140 | mmHg |
| diastolic_bp | eVitals.07 | 60-90 | mmHg |
| temperature_c | eVitals.18 | 36.1-37.2 | °C |
| blood_glucose | eVitals.18 | 4.0-7.8 | mmol/L |
| pain_score | eVitals.27 | 0-10 | VAS |

### 3. eScene — Incident Scene
*Operational data — safe for dispatch AI*

| Field | NEMSIS Element | Values |
|---|---|---|
| incident_type | eScene.09 | Medical / Trauma / Cardiac / Stroke / OB |
| mechanism | eScene.10 | Fall / MVA / Assault / Medical / Burns / Drowning |
| location_type | eScene.08 | Residence / Highway / Public / Industrial |
| number_of_patients | eScene.06 | integer |

### 4. eSituation — Clinical Presentation
*Chief complaint data — de-identified safe*

| Field | NEMSIS Element | Notes |
|---|---|---|
| chief_complaint | eSituation.01 | Free text — scan for PHI before AI |
| primary_symptom | eSituation.09 | Coded — SNOMED CT preferred |
| primary_impression | eSituation.11 | Clinical impression category |
| secondary_impression | eSituation.12 | Additional impressions |
| onset_duration | eSituation.02 | Duration of complaint |

### 5. eMedications — Medications Administered
*Clinical data — check doses against formulary*

| Field | NEMSIS Element | Notes |
|---|---|---|
| medication_name | eMedications.03 | Generic name preferred |
| medication_dose | eMedications.05 | Numeric + unit |
| dose_unit | eMedications.06 | mg / mcg / ml / units |
| route | eMedications.07 | IV / IM / SQ / PO / INH / IO |
| response | eMedications.12 | Improved / Unchanged / Worse |

### 6. eProcedures — Procedures Performed

| Field | NEMSIS Element | Notes |
|---|---|---|
| procedure_name | eProcedures.03 | e.g. IV Access / Intubation / Defibrillation |
| procedure_success | eProcedures.06 | boolean |
| attempts | eProcedures.05 | integer |

### 7. eTimes — Response Timeline
*Operational data — critical for response KPI reporting*

| Field | NEMSIS Element | Notes |
|---|---|---|
| psap_call_time | eTimes.01 | Call received at dispatch |
| dispatch_notified | eTimes.03 | Crew notified |
| unit_en_route | eTimes.05 | Ambulance left base |
| unit_arrived_scene | eTimes.06 | On scene |
| patient_contacted | eTimes.07 | First patient contact |
| unit_left_scene | eTimes.09 | Departed scene |
| unit_arrived_hospital | eTimes.11 | Arrived facility |
| transfer_of_care | eTimes.12 | Patient handed to hospital |

### 8. eDisposition — Transport & Transfer

| Field | NEMSIS Element | Notes |
|---|---|---|
| destination_type | eDisposition.06 | Hospital / Home / Refused / DOA |
| hospital_capability | eDisposition.07 | Trauma / Cardiac / Stroke / General |
| transfer_of_care_name | eDisposition.22 | Receiving clinician — ✅ Strip for AI |

### 9. eArrest — Cardiac Arrest (if applicable)

| Field | NEMSIS Element | Notes |
|---|---|---|
| cardiac_arrest | eArrest.01 | boolean |
| arrest_etiology | eArrest.02 | Cardiac / Respiratory / Trauma |
| cpr_initiated | eArrest.07 | boolean |
| rosc_achieved | eArrest.16 | Return of spontaneous circulation |
| aed_used | eArrest.09 | boolean |

### 10-15. Additional PCR Sections

| Section | NEMSIS | Contents |
|---|---|---|
| ePatientObservations | eOther | Pre-existing conditions |
| ePastIllness | — | Medical history (de-identified) |
| ePregnancy | — | OB-specific vitals |
| ePreHospitalCare | — | BLS/ALS interventions before arrival |
| eEventsDuringTransport | — | Changes during transport |
| ePrintNecessaryDetails | — | Signature fields — always strip |

---

## AI-Safe Field Subset

Fields safe to pass to NEXUS-BRAIN without de-identification:

```
eVitals.*          — all vital signs
eScene.*           — incident scene data
eSituation.*       — chief complaint (scan for PHI first)
eMedications.*     — medication names and doses
eProcedures.*      — procedure names and outcomes
eTimes.*           — all timestamps (no patient identity)
eArrest.*          — cardiac arrest data
eDisposition.*     — transport destination type
```

Fields that ALWAYS require PHI stripping before AI:

```
ePatient.patient_name      → [REDACTED]
ePatient.patient_id        → [REDACTED]
ePatient.dob               → [REDACTED]
ePatient.abha_id           → [REDACTED]
eDisposition.transfer_of_care_name → [REDACTED]
eSituation.chief_complaint → scan + strip before passing
```

---

## MPDS Code Structure

MEDPOD NEXUS uses MPDS (Medical Priority Dispatch System) for triage classification.
MPDS is a public standard maintained by the International Academies of Emergency Dispatch.

```
Format: [Protocol]-[Determinant]-[Suffix]
Example: 32-D-1

Protocol numbers: 1-36 (medical), 27-31 (trauma)
Determinants: A (minor) → B (non-life-threatening) → C (potentially life-threatening) → D (life-threatening) → E (immediately life-threatening)
Suffix: Specific sub-classification
```

Common protocols in Indian EMS context:

| Protocol | Category | Examples |
|---|---|---|
| 9 | Cardiac arrest | 9-E-1 (witnessed), 9-D-1 (unwitnessed) |
| 12 | Convulsions | 12-C-1 (continuous), 12-A-1 (not seizing now) |
| 17 | Falls | 17-D-1 (fall > 6m), 17-A-1 (minor fall) |
| 26 | Sick person | 26-C-1 (unknown problem), 26-A-3 (breathing normally) |
| 29 | Traffic accidents | 29-D-1 (major incident), 29-B-1 (minor) |
| 32 | Unknown problem | 32-D-1 (unconscious), 32-A-1 (alert) |

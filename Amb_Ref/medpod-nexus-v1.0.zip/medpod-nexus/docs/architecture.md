# NEXUS Architecture — Legacy PHP to AI-Ready EMS

## The Core Problem

Legacy EMS platforms built on PHP 5.x / Laravel 5.x accumulate clinical logic
inside controllers — 1,000+ line files mixing HTTP handling, business logic,
DB writes, and real-time notifications. This makes AI integration impossible:

- No service boundaries for AI to call cleanly
- No audit trail for AI invocations
- No PHI protection layer
- No confidence gate infrastructure

## The Solution — Architectural Elevation

> Not a rewrite. An elevation.

78% of clinical domain logic in a typical EMS codebase is directly wrappable.
The patterns are sound. The architecture is what needs lifting.

## The 5-Layer AI Function Stack

Every NEXUS-BRAIN function follows this exact sequence:

```
┌─────────────────────────────────────┐
│  Layer 1: NexusPhiGate::verify()   │  Episode token + role check
├─────────────────────────────────────┤
│  Layer 2: NexusPhiGate::deidentify │  Strip PHI — recursive
├─────────────────────────────────────┤
│  Layer 3: NexusBrainClient::infer  │  Claude API call
├─────────────────────────────────────┤
│  Layer 4: Confidence Gate          │  Reject below threshold
├─────────────────────────────────────┤
│  Layer 5: NexusAuditService::log   │  Append-only audit entry
└─────────────────────────────────────┘
```

## Module Dependencies

```
NEXUS-AUDIT ──────────────────────────────────── Deploy first
    │
NEXUS-TOKEN ──────────────────────────────────── Deploy second
    │
    ├── NEXUS-DISPATCH ─── RealtimeNotifier ───── Sprint 1
    ├── NEXUS-PCR ──────── PCRWriteService ─────── Sprint 1
    ├── NEXUS-NAV ──────── NavService ──────────── Sprint 1
    │
    ├── NEXUS-STOCK ────── StockService ─────────── Sprint 2
    ├── NEXUS-CREW ─────── CrewService ──────────── Sprint 2
    ├── NEXUS-PARTNER ──── PartnerService ────────── Sprint 2
    ├── NEXUS-VAULT ────── VaultService ─────────── Sprint 2
    │
    ├── NEXUS-VOICE ────── VoiceAdapter ─────────── Sprint 4
    │
    └── NEXUS-BRAIN ─────────────────────────────── Phase 5
            │
            ├── StockForecastService    ← Week 1  (lowest risk)
            ├── DispatchOptimisation   ← Week 5
            ├── TriageAssistService    ← Week 9
            └── PcrAnomalyService      ← Week 13 (highest gate)
```

## The PHI Gate Pattern

```php
// Every clinical AI function — same 5 steps, no exceptions
public function recommend(string $episodeToken, array $data, int $userId): array
{
    // 1. Gate
    $this->phiGate->verify($episodeToken, 'dispatcher');

    // 2. Strip
    $safe = $this->phiGate->deidentify($data);

    // 3. Infer
    $result = $this->brain->infer(new MyPrompt($safe));

    // 4. Gate
    if ($result->requiresHumanReview) { $this->escalate(); }

    // 5. Audit
    $this->audit->log('MY_EVENT', ['confidence' => $result->confidence]);

    return $result->payload;
}
```

## Confidence Gates

| Function | Gate | Below Threshold |
|---|---|---|
| StockForecast | 0.75 | Auto-alert still fires |
| DispatchOptimisation | 0.80 | Dispatcher must manually select |
| TriageAssist | 0.85 | Supervisor escalated immediately |
| PcrAnomalyDetection | 0.90 | Senior clinical reviewer required |

## The Episode Token

UPI-inspired signed token for cross-module PHI access:

```
Structure: base64(payload).hmac_sha256(payload, secret)

Payload:
{
  "episode_id":   integer,
  "patient_hash": sha256(patient_id + salt),   // never raw patient_id
  "role":         string,
  "issued_at":    timestamp,
  "expires_at":   timestamp,
  "consent_bits": integer                       // bitmask for DPDP consent
}
```

Token is the ONLY mechanism for cross-module PHI access.
No module accesses another module's PHI tables directly.

## Realtime Architecture (Post PubNub Migration)

```
Dispatcher Console ──WebSocket──► Laravel Reverb ──► Hospital Dashboard
                                       │
                                       ├──► Driver App (Reverb)
                                       ├──► Operator Console (Reverb)
                                       └──► NEXUS-BRAIN events
```

Channel naming:
- `hospital.{id}` — hospital emergency notifications
- `driver.{id}` — driver trip updates
- `operator.{id}` — operator dashboard events
- `trips.{id}` — trip status changes (presence channel)

<?php
declare(strict_types=1);

namespace Medpod\Nexus\Enums;

/**
 * TripStatus — Emergency Medical Services Trip State Machine
 *
 * Status codes follow the NEMSIS / MPDS standard for EMS trip lifecycle.
 * Replaces magic integer comparisons throughout legacy codebases.
 *
 * Valid transitions are enforced via assertValidTransition().
 * Any attempt to skip states (e.g. PENDING → AT_HOSPITAL) throws
 * InvalidTripTransitionException — protecting clinical data integrity.
 */
enum TripStatus: int
{
    case PENDING      = 1;  // Request received — ambulance not yet assigned
    case ASSIGNED     = 2;  // Ambulance assigned — crew notified
    case EN_ROUTE     = 3;  // Ambulance en route to incident
    case ON_SCENE     = 4;  // Ambulance on scene
    case TRANSPORTING = 6;  // Patient on board — en route to hospital
    case AT_HOSPITAL  = 8;  // Arrived at receiving facility
    case COMPLETE     = 9;  // Episode closed — PCR finalised

    /**
     * Valid state transitions — enforces clinical workflow integrity.
     * Derived from MPDS dispatch protocol state machine.
     */
    private const TRANSITIONS = [
        self::PENDING->value      => [self::ASSIGNED->value, self::COMPLETE->value],
        self::ASSIGNED->value     => [self::EN_ROUTE->value, self::PENDING->value],
        self::EN_ROUTE->value     => [self::ON_SCENE->value, self::ASSIGNED->value],
        self::ON_SCENE->value     => [self::TRANSPORTING->value, self::EN_ROUTE->value],
        self::TRANSPORTING->value => [self::AT_HOSPITAL->value],
        self::AT_HOSPITAL->value  => [self::COMPLETE->value],
        self::COMPLETE->value     => [],
    ];

    public function label(): string
    {
        return match($this) {
            self::PENDING      => 'Pending',
            self::ASSIGNED     => 'Assigned',
            self::EN_ROUTE     => 'En Route',
            self::ON_SCENE     => 'On Scene',
            self::TRANSPORTING => 'Transporting',
            self::AT_HOSPITAL  => 'At Hospital',
            self::COMPLETE     => 'Complete',
        };
    }

    public function isActive(): bool
    {
        return !in_array($this, [self::COMPLETE], true);
    }

    public function isClinicallyActive(): bool
    {
        return in_array($this, [
            self::ON_SCENE,
            self::TRANSPORTING,
            self::AT_HOSPITAL,
        ], true);
    }

    public function canTransitionTo(self $next): bool
    {
        return in_array($next->value, self::TRANSITIONS[$this->value] ?? [], true);
    }

    /**
     * @throws InvalidTripTransitionException
     */
    public static function assertValidTransition(self $from, self $to): void
    {
        if (!$from->canTransitionTo($to)) {
            throw new \InvalidArgumentException(
                "Invalid EMS trip transition: {$from->label()} → {$to->label()}"
            );
        }
    }

    public static function fromLabel(string $label): self
    {
        foreach (self::cases() as $case) {
            if (strtolower($case->label()) === strtolower($label)) {
                return $case;
            }
        }
        throw new \ValueError("Unknown TripStatus label: {$label}");
    }
}

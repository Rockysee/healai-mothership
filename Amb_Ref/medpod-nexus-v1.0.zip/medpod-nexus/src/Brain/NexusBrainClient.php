<?php
declare(strict_types=1);

namespace Medpod\Nexus\Brain;

use Illuminate\Support\Facades\Http;
use Medpod\Nexus\Services\NexusAuditService;

/**
 * NexusBrainClient — Anthropic API Integration Layer
 *
 * Single entry point for all NEXUS AI inference functions.
 * No AI function calls the API directly — all inference routes here.
 *
 * Responsibilities:
 * - API authentication and versioning
 * - Pre/post invocation audit logging
 * - Response parsing and confidence extraction
 * - Error handling and retry logic
 * - Token usage tracking
 *
 * Hippocratic constraint enforced upstream by NexusPhiGate.
 * This client assumes de-identified data — never validates PHI itself.
 */
class NexusBrainClient
{
    private const MODEL      = 'claude-sonnet-4-20250514';
    private const MAX_TOKENS = 1024;
    private const API_URL    = 'https://api.anthropic.com/v1/messages';
    private const API_VER    = '2023-06-01';

    public function __construct(
        private readonly NexusAuditService $audit,
        private readonly string $apiKey = '',
    ) {
        $this->apiKey = $apiKey ?: (string) env('NEXUS_ANTHROPIC_API_KEY');
    }

    /**
     * Core inference method — called by all 4 AI services.
     *
     * @throws \RuntimeException on API failure
     * @throws \RuntimeException on JSON parse failure
     */
    public function infer(NexusPrompt $prompt): NexusInferenceResult
    {
        // Pre-inference audit — log intent before any API call
        $this->audit->log('BRAIN_INFERENCE_START', [
            'function'   => $prompt->functionName(),
            'input_hash' => hash('sha256', $prompt->userContent()),
        ]);

        $response = Http::withHeaders([
                'x-api-key'         => $this->apiKey,
                'anthropic-version' => self::API_VER,
                'Content-Type'      => 'application/json',
            ])
            ->timeout(30)
            ->retry(2, 500)
            ->post(self::API_URL, [
                'model'      => self::MODEL,
                'max_tokens' => self::MAX_TOKENS,
                'system'     => $prompt->systemPrompt(),
                'messages'   => [['role' => 'user', 'content' => $prompt->userContent()]],
            ]);

        if (!$response->successful()) {
            $this->audit->log('BRAIN_INFERENCE_FAILED', [
                'function' => $prompt->functionName(),
                'status'   => $response->status(),
            ]);
            throw new \RuntimeException("NEXUS-BRAIN inference failed: " . $response->status());
        }

        // Extract text content block
        $raw = collect($response->json('content'))
            ->where('type', 'text')
            ->first()['text'] ?? '';

        $result = NexusInferenceResult::parse($raw, $prompt->expectedSchema());

        // Post-inference audit — log outcome
        $this->audit->log('BRAIN_INFERENCE_COMPLETE', [
            'function'     => $prompt->functionName(),
            'confidence'   => $result->confidence,
            'human_review' => $result->requiresHumanReview,
        ]);

        return $result;
    }
}

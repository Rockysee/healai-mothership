<?php
declare(strict_types=1);

namespace Medpod\Nexus\Brain;

/**
 * NexusPrompt — Abstract base for all NEXUS AI prompt templates.
 *
 * Each AI function extends this class and defines:
 * - systemPrompt(): Clinical context + output schema instructions
 * - userContent():  De-identified input data as JSON
 * - expectedSchema(): Minimum confidence + required fields
 *
 * All prompts must:
 * 1. Instruct the model to output JSON only — no prose
 * 2. Include a confidence field (0.0 to 1.0)
 * 3. Define behaviour when confidence < threshold
 * 4. Never request or reproduce patient identifiers
 */
abstract class NexusPrompt
{
    abstract public function functionName(): string;
    abstract public function systemPrompt(): string;
    abstract public function userContent(): string;

    /**
     * @return array{min_confidence: float, required_fields: string[]}
     */
    abstract public function expectedSchema(): array;
}


/**
 * NexusInferenceResult — Typed wrapper for AI model responses.
 *
 * Parses raw model JSON output, validates required fields,
 * extracts confidence score, and sets requiresHumanReview flag.
 *
 * The human review flag is the mechanism by which AI recommendations
 * are escalated to clinical staff — it is never suppressed.
 */
readonly class NexusInferenceResult
{
    public function __construct(
        public readonly float  $confidence,
        public readonly bool   $requiresHumanReview,
        public readonly array  $payload,
        public readonly string $rawJson,
    ) {}

    /**
     * @throws \RuntimeException if model response is not valid JSON
     * @throws \RuntimeException if required fields are missing
     */
    public static function parse(string $raw, array $schema): self
    {
        // Strip markdown fences if model includes them
        $clean = trim(preg_replace('/```json|```/', '', $raw));

        $data = json_decode($clean, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \RuntimeException(
                "NEXUS-BRAIN: invalid JSON from model. Raw: " . substr($raw, 0, 200)
            );
        }

        // Validate required fields
        $required = $schema['required_fields'] ?? ['confidence'];
        foreach ($required as $field) {
            if (!array_key_exists($field, $data)) {
                throw new \RuntimeException(
                    "NEXUS-BRAIN: missing required field [{$field}] in model response"
                );
            }
        }

        $confidence = (float) ($data['confidence'] ?? 0.0);
        $minConf    = (float) ($schema['min_confidence'] ?? 0.80);

        return new self(
            confidence:          $confidence,
            requiresHumanReview: $confidence < $minConf,
            payload:             $data,
            rawJson:             $clean,
        );
    }
}

<?php
declare(strict_types=1);

namespace Medpod\Nexus\Brain;

use Medpod\Nexus\Services\{NexusAuditService, NexusPhiGate};

/**
 * TriageAssistService — MPDS Triage Code Recommendation
 *
 * Analyses de-identified vitals and incident data to recommend:
 * - MPDS determinant code (e.g. "32-D-1")
 * - Dispatch priority (1=Immediate, 2=Urgent, 3=Delayed, 4=Minor)
 * - Recommended hospital capability type
 *
 * NEMSIS fields used (de-identified):
 * - eVitals: heart rate, respiratory rate, SpO2, GCS, blood pressure
 * - eScene: incident type, mechanism, location type
 * - eSituation: chief complaint, primary symptom
 *
 * Confidence gate: 0.85
 * Below threshold: escalates to human supervisor immediately.
 * Output is RECOMMENDATION ONLY — dispatcher must confirm.
 */
class TriageAssistService
{
    private const MIN_CONFIDENCE = 0.85;

    public function __construct(
        private readonly NexusBrainClient  $brain,
        private readonly NexusPhiGate      $phiGate,
        private readonly NexusAuditService $audit,
    ) {}

    public function recommend(
        string $episodeToken,
        array  $vitals,    // NEMSIS eVitals — de-identified
        array  $incident,  // NEMSIS eScene — de-identified
        array  $symptoms,  // NEMSIS eSituation — de-identified
        int    $userId
    ): array {
        // Layer 1 — PHI Gate
        $this->phiGate->verify($episodeToken, requiredRole: 'dispatcher');

        // Layer 2 — De-identify
        $safeVitals   = $this->phiGate->deidentify($vitals);
        $safeIncident = $this->phiGate->deidentify($incident);
        $safeSymptoms = $this->phiGate->deidentify($symptoms);

        // Layer 3 — Inference
        $result = $this->brain->infer(new TriagePrompt($safeVitals, $safeIncident, $safeSymptoms));

        // Layer 4 — Confidence gate
        if ($result->requiresHumanReview) {
            $this->audit->log('TRIAGE_ESCALATED', [
                'episode_token' => $episodeToken,
                'confidence'    => $result->confidence,
                'user_id'       => $userId,
            ]);
        }

        // Layer 5 — Audit
        $this->audit->log('TRIAGE_AI_RECOMMEND', [
            'episode_token' => $episodeToken,
            'user_id'       => $userId,
            'mpds_code'     => $result->payload['mpds_code'] ?? null,
            'priority'      => $result->payload['priority'] ?? null,
            'confidence'    => $result->confidence,
            'human_review'  => $result->requiresHumanReview,
        ]);

        return $result->payload;
    }
}


/**
 * TriagePrompt — MPDS Triage System Prompt
 * NEMSIS-aligned field vocabulary. No patient identifiers.
 */
class TriagePrompt extends NexusPrompt
{
    public function __construct(
        private readonly array $vitals,
        private readonly array $incident,
        private readonly array $symptoms,
    ) {}

    public function functionName(): string { return 'TriageAssist'; }

    public function systemPrompt(): string
    {
        return <<<PROMPT
        You are a clinical triage assistant for an Emergency Medical Services platform.
        You receive de-identified emergency incident data — NO patient names, IDs, or DOB.
        Analyse the NEMSIS vital signs, incident scene data, and chief complaint.
        Recommend MPDS (Medical Priority Dispatch System) classification.
        Respond ONLY with valid JSON — no prose, no markdown fences.
        Schema:
        {
          "mpds_code": string,          // e.g. "32-D-1" (MPDS determinant code)
          "priority": integer,           // 1=Immediate 2=Urgent 3=Delayed 4=Minor
          "hospital_capability": string, // "trauma_centre"|"cardiac"|"stroke"|"general"|"paediatric"
          "rationale": string,           // max 100 words — for dispatcher review
          "confidence": float,           // 0.0 to 1.0
          "uncertainty_reason": string   // required if confidence < 0.85
        }
        If confidence < 0.85, explain uncertainty in uncertainty_reason.
        Never invent clinical data. If data is insufficient, lower confidence score.
        PROMPT;
    }

    public function userContent(): string
    {
        return json_encode([
            'vitals'   => $this->vitals,
            'incident' => $this->incident,
            'symptoms' => $this->symptoms,
        ], JSON_PRETTY_PRINT);
    }

    public function expectedSchema(): array
    {
        return [
            'min_confidence'  => 0.85,
            'required_fields' => ['mpds_code', 'priority', 'confidence'],
        ];
    }
}


/**
 * DispatchOptimisationService — Best Ambulance Suggestion
 *
 * Analyses available fleet, crew status, and incident location to suggest
 * the optimal ambulance dispatch. All input data is PHI-free operational data.
 *
 * Input feeds (all AI-safe, no PHI):
 * - Available ambulances with current GPS coordinates
 * - Crew certification status (role + cert validity — no names)
 * - Hospital capability profile (from NEXUS-PARTNER)
 * - Incident coordinates
 *
 * Confidence gate: 0.80
 * Output is SUGGESTION ONLY — dispatcher must accept or reject.
 * Two alternatives always provided for dispatcher choice.
 */
class DispatchOptimisationService
{
    private const MIN_CONFIDENCE = 0.80;

    public function __construct(
        private readonly NexusBrainClient  $brain,
        private readonly NexusAuditService $audit,
    ) {}

    public function suggest(
        int   $tripId,
        array $availableAmbulances,  // from AmbulancePoolService::getAvailable()
        array $crewStatus,           // from CrewService::getAvailableCrewForDispatch()
        array $hospitalCapabilities, // from PartnerService::getProfile()
        float $incidentLat,
        float $incidentLng,
        int   $userId
    ): array {
        $result = $this->brain->infer(new DispatchPrompt(
            $availableAmbulances,
            $crewStatus,
            $hospitalCapabilities,
            $incidentLat,
            $incidentLng,
        ));

        $this->audit->log('DISPATCH_AI_SUGGEST', [
            'trip_id'       => $tripId,
            'user_id'       => $userId,
            'suggested_amb' => $result->payload['ambulance_id'] ?? null,
            'confidence'    => $result->confidence,
            'human_review'  => $result->requiresHumanReview,
        ]);

        return $result->payload;
    }
}


/**
 * DispatchPrompt — Dispatch Optimisation System Prompt
 */
class DispatchPrompt extends NexusPrompt
{
    public function __construct(
        private readonly array $ambulances,
        private readonly array $crew,
        private readonly array $hospital,
        private readonly float $lat,
        private readonly float $lng,
    ) {}

    public function functionName(): string { return 'DispatchOptimisation'; }

    public function systemPrompt(): string
    {
        return <<<PROMPT
        You are a dispatch optimisation AI for an Emergency Medical Services platform.
        You receive operational data only — no patient names or medical records.
        Select the BEST available ambulance based on:
        - Proximity to incident (GPS coordinates provided)
        - Crew certification match to incident type
        - Ambulance type vs incident severity
        - Crew shift duration (fatigue proxy)
        Respond ONLY with JSON:
        {
          "ambulance_id": integer,
          "reason": string,              // max 80 words — dispatcher review
          "estimated_eta_mins": integer,
          "crew_match_score": float,     // 0-1: cert match to incident
          "confidence": float,
          "alternatives": [
            {"ambulance_id": integer, "reason": string}
          ]
        }
        Always provide 2 alternatives. If confidence < 0.80, dispatcher MUST manually select.
        PROMPT;
    }

    public function userContent(): string
    {
        return json_encode([
            'incident_location' => ['lat' => $this->lat, 'lng' => $this->lng],
            'available_ambulances' => $this->ambulances,
            'crew_status'          => $this->crew,
            'hospital_capabilities'=> $this->hospital,
        ], JSON_PRETTY_PRINT);
    }

    public function expectedSchema(): array
    {
        return [
            'min_confidence'  => 0.80,
            'required_fields' => ['ambulance_id', 'confidence', 'alternatives'],
        ];
    }
}


/**
 * StockForecastService — 7-Day Medicine Supply Prediction
 *
 * Analyses 90-day consumption history and current stock levels to predict
 * which medicines will run critically low or expire within 7 days.
 *
 * Input feeds (all PHI-free inventory data):
 * - Current stock levels per ambulance (StockService::getLevels())
 * - Expiring items within 7 days (StockService::getExpiringItems())
 * - 90-day consumption summary (StockService::getConsumptionSummary())
 *
 * Confidence gate: 0.75 (lower — forecasting inherently uncertain)
 * Auto-alerts dispatched if critical items detected, regardless of confidence.
 */
class StockForecastService
{
    private const MIN_CONFIDENCE = 0.75;
    private const FORECAST_DAYS  = 7;
    private const HISTORY_DAYS   = 90;

    public function __construct(
        private readonly NexusBrainClient  $brain,
        private readonly NexusAuditService $audit,
    ) {}

    public function forecast(
        int   $ambulanceId,
        array $currentLevels,      // StockService::getLevels()
        array $expiring,           // StockService::getExpiringItems()
        array $consumptionSummary, // StockService::getConsumptionSummary()
        int   $userId
    ): array {
        $result = $this->brain->infer(new StockForecastPrompt(
            $currentLevels,
            $expiring,
            $consumptionSummary,
            self::FORECAST_DAYS,
        ));

        $critical = array_filter(
            $result->payload['items'] ?? [],
            fn($item) => ($item['status'] ?? '') === 'critical'
        );

        if (!empty($critical)) {
            $this->audit->log('STOCK_CRITICAL_ALERT', [
                'ambulance_id'   => $ambulanceId,
                'critical_items' => array_column($critical, 'medicine'),
                'user_id'        => $userId,
            ]);
        }

        $this->audit->log('STOCK_FORECAST_RUN', [
            'ambulance_id'  => $ambulanceId,
            'user_id'       => $userId,
            'confidence'    => $result->confidence,
            'items_flagged' => count($critical),
        ]);

        return $result->payload;
    }
}


/**
 * StockForecastPrompt — Medicine Forecasting System Prompt
 */
class StockForecastPrompt extends NexusPrompt
{
    public function __construct(
        private readonly array $levels,
        private readonly array $expiring,
        private readonly array $history,
        private readonly int   $days,
    ) {}

    public function functionName(): string { return 'StockForecast'; }

    public function systemPrompt(): string
    {
        return <<<PROMPT
        You are a medical supply forecasting AI for an ambulance EMS platform.
        Analyse 90-day consumption history and current stock levels.
        Predict which medicines will run low or expire in the next 7 days.
        Respond ONLY with JSON:
        {
          "items": [
            {
              "medicine": string,
              "current_qty": float,
              "predicted_usage_7d": float,
              "days_remaining": float,
              "status": "ok"|"low"|"critical"|"expiring",
              "reorder_recommended": boolean
            }
          ],
          "summary": string,     // max 60 words
          "confidence": float    // 0.0 to 1.0
        }
        Definitions: critical = less than 2 days supply OR expiring within 3 days.
        low = less than 5 days supply. ok = sufficient stock.
        PROMPT;
    }

    public function userContent(): string
    {
        return json_encode([
            'forecast_days'       => $this->days,
            'current_levels'      => $this->levels,
            'expiring_soon'       => $this->expiring,
            'consumption_summary' => $this->history,
        ], JSON_PRETTY_PRINT);
    }

    public function expectedSchema(): array
    {
        return [
            'min_confidence'  => 0.75,
            'required_fields' => ['items', 'confidence'],
        ];
    }
}


/**
 * PcrAnomalyService — Clinical Record Quality Assurance
 *
 * Analyses de-identified PCR data across all NEMSIS sections to detect:
 * - Incomplete or missing required fields
 * - Vital sign values outside physiological norms
 * - Medication doses outside standard ranges
 *
 * NEMSIS sections analysed:
 * eVitals, ePatient (de-identified), eScene, eSituation,
 * eMedications, eProcedures, eDisposition, eTimes,
 *
 * Confidence gate: 0.90 — HIGHEST gate in NEXUS-BRAIN.
 * Clinical decisions may be affected by this output.
 * Double PHI gate: episode token + clinical_reviewer role.
 * Output is QA REPORT ONLY — clinical reviewer must act on findings.
 */
class PcrAnomalyService
{
    private const MIN_CONFIDENCE = 0.90;

    private const NEMSIS_SECTIONS = [
        'eVitals',        // Vital signs — HR, RR, SpO2, GCS, BP
        'eScene',         // Scene information
        'eSituation',     // Chief complaint, primary impression
        'eMedications',   // Medications administered
        'eProcedures',    // Procedures performed
        'eDisposition',   // Hospital destination, transfer of care
        'eTimes',         // Response timeline
        'eArrest',        // Cardiac arrest data if applicable
    ];

    public function __construct(
        private readonly NexusBrainClient  $brain,
        private readonly NexusPhiGate      $phiGate,
        private readonly NexusAuditService $audit,
    ) {}

    public function analyse(
        string $episodeToken,
        int    $episodeId,
        array  $pcrSections, // All NEMSIS sections — de-identified before passing here
        int    $userId
    ): array {
        // Double PHI gate — maximum sensitivity
        $this->phiGate->verify($episodeToken, requiredRole: 'clinical_reviewer');
        $this->phiGate->verifyEpisodeActive($episodeToken);

        // De-identify all sections
        $safeSections = array_map(
            fn($section) => $this->phiGate->deidentify($section),
            $pcrSections
        );

        $result = $this->brain->infer(new PcrAnomalyPrompt($safeSections));

        if ($result->requiresHumanReview) {
            $this->audit->log('PCR_ANOMALY_ESCALATED', [
                'episode_id' => $episodeId,
                'confidence' => $result->confidence,
                'user_id'    => $userId,
            ]);
        }

        $this->audit->log('PCR_ANOMALY_ANALYSIS', [
            'episode_id'        => $episodeId,
            'user_id'           => $userId,
            'anomalies_found'   => count($result->payload['anomalies'] ?? []),
            'incomplete_fields' => count($result->payload['incomplete'] ?? []),
            'confidence'        => $result->confidence,
            'human_review'      => $result->requiresHumanReview,
        ]);

        return $result->payload; // Field names only — no raw PHI in return
    }
}


/**
 * PcrAnomalyPrompt — PCR Quality Assurance System Prompt
 * Uses NEMSIS field vocabulary throughout.
 */
class PcrAnomalyPrompt extends NexusPrompt
{
    public function __construct(
        private readonly array $sections,
    ) {}

    public function functionName(): string { return 'PcrAnomalyDetection'; }

    public function systemPrompt(): string
    {
        return <<<PROMPT
        You are a clinical documentation QA AI for an EMS platform.
        You receive de-identified NEMSIS Patient Care Record sections.
        No patient names, IDs, dates of birth, or contact details are present.
        Identify:
          1. Incomplete or missing required NEMSIS fields
          2. Vital sign values outside physiological norms for adults
             (HR: 40-180, RR: 8-40, SpO2: <85% flag, GCS: 3-15, SBP: 60-220)
          3. Medication doses outside standard EMS formulary ranges
        Respond ONLY with JSON:
        {
          "anomalies": [
            {
              "section": string,      // NEMSIS section name e.g. "eVitals"
              "field": string,        // NEMSIS field name
              "issue": string,        // Description of the anomaly
              "severity": "low"|"medium"|"high"
            }
          ],
          "incomplete": [
            {
              "section": string,
              "field": string,
              "required": boolean
            }
          ],
          "overall_completeness": float,  // 0.0-1.0
          "clinical_flags": integer,       // count of high-severity anomalies
          "confidence": float              // 0.0-1.0
        }
        High severity = immediate clinical attention required.
        If confidence < 0.90, flag for senior clinical reviewer.
        Never invent clinical data. Report only what is present in the record.
        PROMPT;
    }

    public function userContent(): string
    {
        return json_encode($this->sections, JSON_PRETTY_PRINT);
    }

    public function expectedSchema(): array
    {
        return [
            'min_confidence'  => 0.90,
            'required_fields' => ['anomalies', 'incomplete', 'confidence'],
        ];
    }
}

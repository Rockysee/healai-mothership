<?php
declare(strict_types=1);

namespace Medpod\Nexus\Services;

/**
 * NexusPhiGate — Patient Health Information Protection Layer
 *
 * Every AI function that touches clinical data passes through this gate.
 * No raw PHI ever reaches the inference layer.
 *
 * The gate enforces three checks:
 * 1. Episode token validity (HMAC signature verification)
 * 2. Role authorisation (dispatcher / paramedic / clinical_reviewer)
 * 3. De-identification (recursive PHI field stripping)
 *
 * Hippocratic constraint: patient safety overrides engineering convenience.
 * This gate cannot be bypassed — it is not configurable at runtime.
 *
 * PHI field list aligned to:
 * - DPDP Act 2023 (India) — sensitive personal data categories
 * - ABDM Health Data Management Policy
 * - NEMSIS data dictionary — patient identifier fields
 */
class NexusPhiGate
{
    /**
     * NEMSIS + DPDP Act sensitive fields — never passed to AI inference.
     * Extend this list as new PHI fields are identified in your schema.
     */
    private const PHI_FIELDS = [
        // Identity
        'patient_name', 'first_name', 'last_name', 'name',
        'patient_id', 'mrn', 'abha_id', 'aadhaar',
        'dob', 'date_of_birth', 'age',

        // Contact
        'mobile', 'phone', 'email', 'address',
        'street', 'city', 'pincode', 'landmark',

        // Family
        'next_of_kin', 'guardian_name', 'guardian_contact',
        'father_name', 'mother_name',

        // Financial / Insurance
        'insurance_id', 'policy_number', 'employer',
        'income', 'occupation',

        // Clinical identifiers (keep clinical data, strip identifiers)
        'referring_physician_name',
        'receiving_physician_name',
    ];

    public function __construct(
        private readonly NexusTokenService $tokenService,
    ) {}

    /**
     * Verify episode token and role authorisation.
     *
     * @throws \RuntimeException if token invalid or role insufficient
     */
    public function verify(string $episodeToken, string $requiredRole): void
    {
        if (!$this->tokenService->verify($episodeToken, $requiredRole)) {
            throw new \RuntimeException(
                "PHI Gate: invalid token or insufficient role [{$requiredRole}]"
            );
        }
    }

    public function verifyEpisodeActive(string $episodeToken): void
    {
        if ($this->tokenService->isExpired($episodeToken)) {
            throw new \RuntimeException('PHI Gate: episode token expired');
        }
    }

    /**
     * Recursively strip all PHI fields from a data array.
     * Safe to pass the result to NexusBrainClient.
     *
     * @param  array $data  Raw clinical data (may contain PHI)
     * @return array        De-identified data — safe for AI inference
     */
    public function deidentify(array $data): array
    {
        return $this->recursiveStrip($data, self::PHI_FIELDS);
    }

    private function recursiveStrip(array $data, array $fields): array
    {
        foreach ($data as $key => &$value) {
            if (in_array(strtolower((string) $key), $fields, true)) {
                $value = '[REDACTED]';
            } elseif (is_array($value)) {
                $value = $this->recursiveStrip($value, $fields);
            }
        }
        return $data;
    }
}

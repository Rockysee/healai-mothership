<?php
declare(strict_types=1);

namespace Medpod\Nexus\Services;

use Illuminate\Support\Facades\{Auth, DB};

/**
 * NexusAuditService — Append-Only Clinical Audit Log
 *
 * Every write operation in a NEXUS module routes through this service.
 * Every AI inference invocation logs before AND after execution.
 *
 * Design principles:
 * - Append-only: UPDATE and DELETE are revoked at the database level
 * - PHI-safe: patient identifiers are stripped before logging
 * - Tamper-evident: SHA-256 hash of sanitised payload stored with each entry
 * - Zero-trust: logs even failed operations
 *
 * Database setup:
 *   REVOKE UPDATE, DELETE ON nexus_audit_log FROM your_app_db_user;
 */
class NexusAuditService
{
    /**
     * PHI fields never logged — stripped before hashing.
     * Aligned to DPDP Act 2023 sensitive personal data categories.
     */
    private const PHI_STRIP = [
        'patient_name',
        'patient_id',
        'dob',
        'date_of_birth',
        'mobile',
        'phone',
        'aadhaar',
        'abha_id',
        'address',
        'next_of_kin',
        'insurance_id',
        'employer',
        'diagnosis',       // Strip raw diagnosis — keep category only
        'medication_name', // Strip specific medication — keep class only
    ];

    public function log(string $eventType, array $payload): void
    {
        // Strip PHI before any processing
        $safe = $this->stripPhi($payload);

        DB::table('nexus_audit_log')->insert([
            'event_type'             => $eventType,
            'episode_token'          => $payload['episode_token'] ?? null,
            'user_id'                => Auth::id() ?? $payload['user_id'] ?? 0,
            'role_at_invoke'         => Auth::user()?->primaryRole() ?? 'system',
            'payload_hash'           => hash('sha256', json_encode($safe)),
            'confidence_score'       => $payload['confidence'] ?? null,
            'human_review_required'  => $payload['human_review'] ?? false,
            'outcome'                => json_encode($safe),
            'created_at'             => now(),
            'ip_address'             => request()?->ip(),
        ]);
    }

    private function stripPhi(array $data): array
    {
        return array_filter(
            $data,
            fn($key) => !in_array(strtolower($key), self::PHI_STRIP, true),
            ARRAY_FILTER_USE_KEY
        );
    }
}

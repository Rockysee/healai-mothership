<?php
declare(strict_types=1);

namespace Medpod\Nexus\Contracts;

/**
 * VoiceAdapter — Provider-Agnostic Telephony Interface
 *
 * Implemented by ExotelAdapter (Indian EMS standard) and TwilioAdapter (fallback).
 * Switch providers via NEXUS_VOICE_DRIVER environment variable.
 *
 * PHI note: phone numbers are hashed before storage.
 * Raw "to" numbers never stored in nexus_call_records — SHA-256 only.
 */
interface VoiceAdapter
{
    /**
     * Initiate an outbound call from dispatcher to patient/hospital.
     *
     * @param  string $from      Caller ID (dispatcher line)
     * @param  string $to        Destination number (hashed before storage)
     * @param  array  $metadata  Context: ['trip_id' => int, 'call_type' => string]
     * @return array             Call record with call_sid and initial status
     */
    public function initiateCall(string $from, string $to, array $metadata): array;

    /**
     * Poll current status of an in-progress call.
     *
     * @param  string $callSid   Provider call identifier
     * @return array             ['status' => string, 'duration' => int|null]
     */
    public function getCallStatus(string $callSid): array;

    /**
     * Handle inbound provider webhook (call answered, ended, failed).
     *
     * @param  array $payload    Raw webhook payload from provider
     * @return array             Normalised call event
     */
    public function handleWebhook(array $payload): array;

    /**
     * Retrieve all calls associated with a trip — for PCR timeline enrichment.
     * Returns call metadata only — no raw phone numbers.
     *
     * @param  int $tripId
     * @return array
     */
    public function getCallsForTrip(int $tripId): array;
}

# 🚑 MEDPOD NEXUS

> **PHP/Laravel Legacy → AI-Ready Emergency Management Platform**
> Open-source architectural intelligence extracted from a real-world EMS modernisation project.

[![License: MIT](https://img.shields.io/badge/License-MIT-teal.svg)](LICENSE)
[![PHP: 8.3+](https://img.shields.io/badge/PHP-8.3%2B-navy.svg)](https://php.net)
[![Laravel: 11](https://img.shields.io/badge/Laravel-11-red.svg)](https://laravel.com)
[![Anthropic: Claude](https://img.shields.io/badge/AI-Claude%20Sonnet-orange.svg)](https://anthropic.com)

---

## What This Is

MEDPOD NEXUS is a **battle-tested architectural pattern** for elevating legacy PHP/Laravel emergency management platforms into AI-ready systems — without a full rewrite.

Built from analysing **1,784 PHP files**, **783 audit findings**, and **6 critical red flags** in a production Indian EMS codebase. The intelligence is open. The private data is not.

---

## The NEXUS Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      NEXUS-BRAIN                            │
│   TriageAssist · DispatchOptimise · StockForecast · PCRAnom │
├──────────────┬──────────────┬──────────────┬────────────────┤
│NEXUS-DISPATCH│  NEXUS-PCR   │  NEXUS-NAV   │  NEXUS-STOCK   │
├──────────────┼──────────────┼──────────────┼────────────────┤
│  NEXUS-CREW  │NEXUS-PARTNER │  NEXUS-VAULT │  NEXUS-VOICE   │
├──────────────┴──────────────┴──────────────┴────────────────┤
│              NEXUS-AUDIT  ·  NEXUS-TOKEN                    │
└─────────────────────────────────────────────────────────────┘
```

| Module | Purpose | Phase |
|---|---|---|
| NEXUS-DISPATCH | Emergency dispatch, trip state machine, ambulance assignment | 1 |
| NEXUS-PCR | Patient Care Record — 15-section NEMSIS-adjacent clinical record | 1 |
| NEXUS-NAV | Real-time ambulance tracking, location updates, routing | 1 |
| NEXUS-TOKEN | Episode token — UPI-like signed token for cross-module PHI access | 1 |
| NEXUS-AUDIT | Append-only immutable audit log — foundation for all AI functions | 1 |
| NEXUS-STOCK | Medicine inventory, equipment, expiry scheduling | 2 |
| NEXUS-CREW | Staff management, certification tracking, crew availability | 2 |
| NEXUS-PARTNER | Hospital/partner CRM, contracts, SLA webhooks | 2 |
| NEXUS-VAULT | Document storage — S3/MinIO migration from local filesystem | 2 |
| NEXUS-VOICE | Telephony adapter — Exotel/Twilio for dispatch calls | 3 |
| NEXUS-BRAIN | AI inference layer — 4 clinical AI functions | 5 |

---

## The Four AI Functions

All outputs are **recommendations only** — never replacing clinical judgement.

### 1. TriageAssist
- **Input:** De-identified vitals + incident data (NEMSIS fields)
- **Output:** MPDS determinant code + dispatch priority (1-4) + hospital capability type
- **Confidence gate:** 0.85 — below threshold escalates to human supervisor
- **PHI:** Double-gated — episode token + `dispatcher` role required

### 2. DispatchOptimisation
- **Input:** Available ambulances + crew status + hospital capabilities + incident coordinates
- **Output:** Ranked ambulance suggestion + ETA + crew match score + 2 alternatives
- **Confidence gate:** 0.80
- **PHI:** None — pure operational data

### 3. StockForecast
- **Input:** 90-day medicine consumption summary + current levels + expiring items
- **Output:** 7-day per-medicine forecast (ok/low/critical/expiring) + reorder flags
- **Confidence gate:** 0.75
- **PHI:** None — inventory data only

### 4. PCRAnomalyDetection
- **Input:** De-identified PCR across all 15 NEMSIS sections
- **Output:** Incomplete field flags + vital sign outliers + medication dose anomalies
- **Confidence gate:** 0.90 — highest gate, clinical decisions affected
- **PHI:** Maximum sensitivity — double gate + `clinical_reviewer` role required

---

## PHI Protection Pattern

```php
// Every AI function follows this 5-layer pattern:
// Layer 1 — PHI Gate:     verify episode token + role
// Layer 2 — De-identify:  strip patient_name, dob, aadhaar, abha_id etc.
// Layer 3 — Inference:    send de-identified data to NexusBrainClient
// Layer 4 — Confidence:   reject below threshold, escalate to human
// Layer 5 — Audit:        append-only log of every invocation
```

---

## Token-Efficient Codebase Scanner

Scan **4,000+ PHP files in under 15,000 tokens** using the 4-phase funnel:

```
Phase 0 — Manifest    ~500 tokens    All files — path, size, NEXUS classification
Phase 1 — Skeleton    ~2,000 tokens  Class/method signatures only — no bodies
Phase 3 — Audit       ~1,000 tokens  Grep-style pattern matching — no full reads
Phase 2 — Deep Read   ~8,000 tokens  Triggered files only (~40-80 files)
─────────────────────────────────────────────────────────────
Total                 ~11,500 tokens  vs millions for naive full-file scanning
```

---

## Quick Start

```bash
# 1. Clone
git clone https://github.com/your-org/medpod-nexus.git
cd medpod-nexus

# 2. Install
composer require medpod/nexus

# 3. Publish config
php artisan vendor:publish --tag=nexus-config

# 4. Run migrations (NEXUS-AUDIT first — always)
php artisan migrate --path=database/migrations/nexus

# 5. Set environment variables
cp stubs/.env.example .env
# Fill in NEXUS_ANTHROPIC_API_KEY and other vars

# 6. Register service provider
# Add to config/app.php providers:
# App\Providers\NexusBrainServiceProvider::class

# 7. Scan your legacy codebase
php src/Scanner/phase0_manifest.php /path/to/wwwroot
php src/Scanner/phase1_skeleton.php
php src/Scanner/phase3_audit.php
php src/Scanner/phase2_deepread.php
```

---

## Definition of Done — Per Module

A NEXUS module is **AI-Ready** when:

- [ ] Service layer extracted from Controller — no business logic in controllers
- [ ] `NexusAuditService::log()` on every DB write
- [ ] Episode token gate on every PHI operation
- [ ] `declare(strict_types=1)` in every new service file
- [ ] PHPUnit test coverage ≥ 80%
- [ ] Laravel Dusk smoke test passing
- [ ] PHP 8.3 compatible (rector upgrade complete)
- [ ] All credentials in secrets manager — nothing hardcoded
- [ ] Staging validated before production cutover
- [ ] Red flags resolved (see `SECURITY.md`)

---

## Regulatory Alignment (Indian EMS)

- **DPDP Act 2023** — consent bitmask in episode token, purpose limitation in audit log
- **ABDM (Ayushman Bharat Digital Mission)** — ABHA ID field in PHI strip list
- **NEMSIS** — PCR field structure aligned to international EMS standard
- **IT Act** — security practices for digital health records

---

## Contributing

This project welcomes contributions. Clinical domain expertise, Laravel patterns, AI integration improvements — all welcome.

**What belongs here:** Patterns, interfaces, generic scaffolds, documentation.
**What does not belong here:** Real patient data, private credentials, production configs.

See `CONTRIBUTING.md` for guidelines.

---

## License

MIT — use freely, attribute kindly.

---

*Built with 🙏 Shree Ganeshay Namah — may all obstacles be removed.*

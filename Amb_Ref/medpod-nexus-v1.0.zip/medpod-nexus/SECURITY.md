# Security Policy

## Red Flag Classification System

MEDPOD NEXUS uses a Red Flag (RF) system to classify security and architectural risks
in legacy EMS codebases. Each RF has a severity, detection pattern, and remediation path.

| ID | Severity | Type | Detection Pattern | Remediation |
|---|---|---|---|---|
| RF-001 | 🔴 CRITICAL | Hardcoded private key | `BEGIN PRIVATE KEY` in PHP source | Rotate immediately. Move to `env()` + secrets manager. |
| RF-002 | 🔴 HIGH | EOL realtime SDK | PubNub 3.8.x references | Migrate to Laravel Reverb (WebSocket) or PubNub v7+ |
| RF-003 | 🟠 HIGH | EOL framework | Laravel 5.x in composer.json | Step upgrade via rector: 5.x → 6 → 8 → 9 → 10 → 11 |
| RF-004 | 🟠 HIGH | Empty handler stubs | `function name() {}` in Handler classes | Implement with RealtimeNotifier + NexusAuditService |
| RF-005 | 🟡 MEDIUM | Local file storage | `public_path('/uploads')` | Migrate to Laravel Storage with S3/MinIO driver |
| RF-006 | 🟡 MEDIUM | Missing throttle | Dispatch routes without rate limiting | Apply throttle middleware. API gateway preferred. |

## Responsible Disclosure

If you discover a security vulnerability in this project, please:

1. **Do not** open a public GitHub issue
2. Email: security@your-org.com
3. Include: description, reproduction steps, impact assessment
4. Allow 90 days for remediation before public disclosure

## PHI Handling

This project operates under the Hippocratic constraint:

> **Patient safety overrides engineering elegance. Always.**

All AI functions produce recommendations only. No AI output replaces
clinical judgement. PHI never reaches the inference layer — the NexusPhiGate
strips all identifying fields before any data is passed to the model.

**Fields always stripped before AI inference:**
- `patient_name`, `patient_id`
- `dob` (date of birth)
- `mobile`, `phone`
- `aadhaar`, `abha_id`
- `address`, `next_of_kin`
- `insurance_id`, `employer`

## Compliance

- DPDP Act 2023 (India)
- ABDM / Ayushman Bharat Digital Mission
- IT Act (India)
- NEMSIS (National EMS Information System — USA standard adopted internationally)

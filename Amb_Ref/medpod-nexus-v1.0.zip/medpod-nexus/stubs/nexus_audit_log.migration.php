<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\{Schema, DB};

/**
 * NEXUS-AUDIT: Append-Only Clinical Audit Log
 *
 * CRITICAL: After running this migration, execute the REVOKE statement
 * to make this table truly append-only at the database level.
 *
 * Replace 'your_app_db_user' with the actual DB user your Laravel app uses.
 *
 * For PostgreSQL (recommended for NEXUS):
 *   REVOKE UPDATE, DELETE ON nexus_audit_log FROM your_app_db_user;
 *
 * For MySQL:
 *   REVOKE UPDATE, DELETE ON medpod.nexus_audit_log FROM 'your_app_db_user'@'localhost';
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('nexus_audit_log', function (Blueprint $table) {
            $table->id();

            // Event classification
            $table->string('event_type', 60)
                ->comment('e.g. AMBULANCE_ASSIGNED, PCR_PATIENT_UPDATE, BRAIN_INFERENCE_COMPLETE');

            // Clinical context — nullable for non-clinical events
            $table->string('episode_token', 128)
                ->nullable()
                ->comment('NEXUS episode token — links audit entry to clinical episode');

            // Actor
            $table->unsignedBigInteger('user_id')
                ->comment('User who triggered the event — 0 for system events');
            $table->string('role_at_invoke', 40)
                ->comment('Role at time of invocation — dispatcher|paramedic|clinical_reviewer|system');

            // Tamper detection
            $table->string('payload_hash', 64)
                ->comment('SHA-256 of sanitised payload — PHI stripped before hashing');

            // AI-specific fields — null for non-AI events
            $table->decimal('confidence_score', 5, 4)
                ->nullable()
                ->comment('AI inference confidence 0.0000-1.0000 — null for non-AI events');
            $table->boolean('human_review_required')
                ->default(false)
                ->comment('True when confidence below threshold — triggers supervisor escalation');

            // Sanitised outcome — no raw PHI
            $table->json('outcome')
                ->nullable()
                ->comment('Sanitised event data — PHI fields stripped before storage');

            // Timestamp — no updated_at (append-only)
            $table->timestampTz('created_at')
                ->useCurrent()
                ->comment('Immutable creation timestamp — never updated');

            // Network context
            $table->ipAddress('ip_address')
                ->nullable();

            // Indexes for common queries
            $table->index(['event_type', 'created_at'], 'idx_audit_event_time');
            $table->index('episode_token', 'idx_audit_episode');
            $table->index(['user_id', 'created_at'], 'idx_audit_user_time');
        });

        // ─── REVOKE modification permissions ─────────────────────────────────
        // Uncomment and replace 'your_app_db_user' before running in production.
        // This makes the table truly append-only at the DB level.
        //
        // DB::statement("REVOKE UPDATE, DELETE ON nexus_audit_log FROM your_app_db_user");
    }

    public function down(): void
    {
        // Note: dropping this table in production should require explicit approval.
        Schema::dropIfExists('nexus_audit_log');
    }
};
